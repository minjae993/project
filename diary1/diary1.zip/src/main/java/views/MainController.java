package views;

import domain.UserVO;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import main.MainApp;

public class MainController extends MasterController{
	@FXML
	private Button btnPrev;
	@FXML
	private Button btnNext;
	@FXML
	private Label lblDate;
	@FXML
	private Label lblDay;
	@FXML
	private Label loginInfo;
	@FXML
	private GridPane gridCalendar;
	
	private UserVO user;
	
	public void setLoginInfo(UserVO vo) {
		this.user = vo;
		loginInfo.setText(vo.getName() + "[" + vo.getId() + "]");
	}
	
	public void logout() {
		user = null;
		MainApp.app.loadPage("login");
	}
	
	public void prevMonth() {
		
	}
	
	public void nextMonth() {
		
	}
	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}
	
}
